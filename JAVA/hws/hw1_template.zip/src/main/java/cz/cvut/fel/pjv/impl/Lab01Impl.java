package cz.cvut.fel.pjv.impl;

import cz.cvut.fel.pjv.Lab01;

public class Lab01Impl implements Lab01 {
    @Override
    public void homework() {
        // TODO: Implement the homework here
    }
}
