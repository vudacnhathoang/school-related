package cz.cvut.fel.pjv;

public interface Lab01 {

    void homework();

}
