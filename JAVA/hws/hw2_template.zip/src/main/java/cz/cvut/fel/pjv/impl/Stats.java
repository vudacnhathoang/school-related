package cz.cvut.fel.pjv.impl;

import cz.cvut.fel.pjv.StatsInterface;

public class Stats implements StatsInterface {
    // TODO implement all methods from StatsInterface
    @Override
    public void addNumber(double number) {

    }

    @Override
    public double getAverage() {
        return 0;
    }

    @Override
    public double getStandardDeviation() {
        return 0;
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public String getFormattedStatistics() {
        return "";
    }
}
