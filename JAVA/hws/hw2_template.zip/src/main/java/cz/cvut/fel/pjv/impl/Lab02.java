package cz.cvut.fel.pjv.impl;

public class Lab02 {
    public void main(String[] args) {
        System.out.println("I'm not implemented!");
    }
}