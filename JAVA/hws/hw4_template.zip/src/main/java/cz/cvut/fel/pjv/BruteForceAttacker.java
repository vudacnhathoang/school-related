package cz.cvut.fel.pjv;

public class BruteForceAttacker {
    // TODO
}
