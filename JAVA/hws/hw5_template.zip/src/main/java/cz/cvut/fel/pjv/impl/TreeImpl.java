package cz.cvut.fel.pjv.impl;

import cz.cvut.fel.pjv.Node;
import cz.cvut.fel.pjv.Tree;

public class TreeImpl implements Tree {

    // TODO: implement this class

    @Override
    public void setTree(int[] values) {
    }

    @Override
    public Node getRoot() {
        return null;
    }

    @Override
    public String toString() {
        return "";
    }

}
